# College-Python-Weekly
This repository contains the Moodle(Digital cafe) codes that have been practiced every week at Rajalaksmi College of Engineering Chennai(REC)
